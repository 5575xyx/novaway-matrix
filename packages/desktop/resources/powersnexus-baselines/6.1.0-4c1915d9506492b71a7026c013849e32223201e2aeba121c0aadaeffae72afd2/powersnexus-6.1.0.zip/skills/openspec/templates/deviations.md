# Design Deviations

> 模板来源：PowersNexus OpenSpec
> 路径：`.novaway/powersnexus/changes/<name>/deviations.md`
> 用途：记录实施过程中偏离设计文档的所有变更

---

## Deviation Log

| ID | Date | Description | Original Design | Proposed Change | Reason | Impact | Approval |
|----|------|-------------|-----------------|-----------------|--------|--------|----------|
| DEV-001 | {{DATE}} | {{DESCRIPTION}} | {{ORIGINAL}} | {{CHANGE}} | {{REASON}} | {{IMPACT}} | {{APPROVAL}} |

---

## Deviation Details

### DEV-001: {{TITLE}}

**Original Design:**
{{DETAILED_ORIGINAL_DESIGN}}

**Proposed Change:**
{{DETAILED_PROPOSED_CHANGE}}

**Reason:**
{{DETAILED_REASON}}

**Impact Analysis:**
- Affected modules: {{LIST}}
- Risk level: {{LEVEL}}
- Testing required: {{YES/NO}}
- Regression potential: {{LOW/MEDIUM/HIGH}}

**Approval:**
- [ ] Approved
- [ ] Rejected (back to original design)
- [ ] Pending discussion

**Reviewer Notes:**
{{NOTES}}

---

## Summary

| Status | Count |
|--------|-------|
| Approved | {{N}} |
| Rejected | {{N}} |
| Pending | {{N}} |
| Total | {{N}} |

---

**使用说明：**
- 当实施者发现设计与实际不符时创建此文件
- 每个偏离必须包含完整的理由和影响分析
- 必须获得用户批准才能继续
- 审查者在验证时必须检查此文件