# Proposal: {{CHANGE_NAME}}

> 模板来源：PowersNexus OpenSpec
> 路径：`.novaway/powersnexus/changes/<name>/proposal.md`

## Intent

**问题陈述：** {{PROBLEM_STATEMENT}}
> 描述我们正在解决的问题。为什么这个问题重要？谁受影响？当前的痛点是什么？

**目标：** {{GOAL}}
> 一句话描述这个变更要实现什么。

## Scope

### In scope
- {{IN_SCOPE_1}}
- {{IN_SCOPE_2}}

### Out of scope
- {{OUT_OF_SCOPE_1}}
- {{OUT_OF_SCOPE_2}}

### Future scope (Post-MVP)
- {{FUTURE_SCOPE_1}}

## Approach

**推荐方案：** {{RECOMMENDED_APPROACH}}
> 描述我们将采用的技术方向和核心策略。

**备选方案考虑：**
| 方案 | 优势 | 劣势 | 放弃原因 |
|------|------|------|----------|
| {{ALT_1}} | {{PROS}} | {{CONS}} | {{WHY_REJECTED}} |

**假设条件：**
- {{ASSUMPTION_1}}
- {{ASSUMPTION_2}}

**依赖关系：**
- 前置依赖：{{DEPENDENCIES_BEFORE}}
- 后续影响：{{DEPENDENCIES_AFTER}}

## Success Criteria

**功能成功标准：**
- [ ] {{SC_1}} — 验证方法：{{VERIFICATION_METHOD}}
- [ ] {{SC_2}} — 验证方法：{{VERIFICATION_METHOD}}

**质量成功标准：**
- [ ] 单元测试覆盖率达到 {{COVERAGE_TARGET}}%
- [ ] 所有 CI 检查通过
- [ ] 代码审查获得批准

**业务成功指标（可选）：**
- {{KPI_1}}：{{TARGET_VALUE}}
- {{KPI_2}}：{{TARGET_VALUE}}

## Stakeholders

| 角色 | 姓名/团队 | 关注点 | 沟通方式 |
|------|----------|--------|----------|
| {{ROLE}} | {{NAME}} | {{CONCERN}} | {{COMMUNICATION}} |

## Timeline

- **预估工作量：** {{ESTIMATED_EFFORT}}
- **关键里程碑：**
  - M1: {{MILESTONE_1}} — {{DATE}}
  - M2: {{MILESTONE_2}} — {{DATE}}
  - M3: {{MILESTONE_3}} — {{DATE}}

## Risks & Mitigations

| 风险 | 可能性 | 影响 | 缓解策略 |
|------|--------|------|----------|
| {{RISK_1}} | {{LIKELIHOOD}} | {{IMPACT}} | {{MITIGATION}} |

## Open Questions

- {{QUESTION_1}}
- {{QUESTION_2}}

## Approval

- [ ] 技术负责人：___
- [ ] 产品负责人：___
- [ ] 变更日期：___