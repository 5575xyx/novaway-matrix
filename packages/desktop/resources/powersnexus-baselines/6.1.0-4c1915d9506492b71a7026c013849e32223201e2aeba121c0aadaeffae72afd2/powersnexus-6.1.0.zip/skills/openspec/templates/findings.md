# Findings - {{EXPLORATION_NAME}}

> 模板来源：PowersNexus OpenSpec
> 路径：`.novaway/powersnexus/explorations/<name>/findings.md`
> 用途：总结探索的发现和结论

---

## 探索概述

| 项目 | 内容 |
|------|------|
| **探索名称** | {{EXPLORATION_NAME}} |
| **时间跨度** | {{DATE_RANGE}} |
| **原始假设** | {{ORIGINAL_HYPOTHESIS}} |
| **探索目标** | {{GOALS}} |

---

## 假设验证结果

### 核心假设

| 假设 | 验证结果 | 置信度 | 证据 |
|------|----------|--------|------|
| {{HYPOTHESIS_1}} | ✅ 已验证 / ❌ 已推翻 / ⚠️ 部分验证 | 高/中/低 | {{EVIDENCE}} |
| {{HYPOTHESIS_2}} | ✅ 已验证 / ❌ 已推翻 / ⚠️ 部分验证 | 高/中/低 | {{EVIDENCE}} |

---

## 关键发现

### 1. {{FINDING_TITLE_1}}

**描述：**
{{DETAILED_DESCRIPTION}}

**证据：**
- {{EVIDENCE_1}}
- {{EVIDENCE_2}}
- {{EVIDENCE_3}}

**影响：**
- 对架构的影响：{{IMPACT}}
- 对性能的影响：{{IMPACT}}
- 对开发效率的影响：{{IMPACT}}

---

### 2. {{FINDING_TITLE_2}}

**描述：**
{{DETAILED_DESCRIPTION}}

**证据：**
- {{EVIDENCE_1}}
- {{EVIDENCE_2}}

**影响：**
{{IMPACT}}

---

## 已验证的方案

| 方案 | 结论 | 优势 | 劣势 | 推荐度 |
|------|------|------|------|--------|
| {{APPROACH_1}} | 可行/不可行/有条件可行 | {{PROS}} | {{CONS}} | ⭐⭐⭐⭐⭐ |
| {{APPROACH_2}} | 可行/不可行/有条件可行 | {{PROS}} | {{CONS}} | ⭐⭐⭐ |

---

## 意外发现

| 发现 | 相关领域 | 重要性 | 后续行动 |
|------|----------|--------|----------|
| {{DISCOVERY}} | {{AREA}} | 高/中/低 | {{ACTION}} |

---

## 风险和不确定性

### 已识别的风险

| 风险 | 可能性 | 影响 | 缓解措施 |
|------|--------|------|----------|
| {{RISK}} | 高/中/低 | 高/中/低 | {{MITIGATION}} |

### 未知领域

- {{UNKNOWN_1}} - 需要进一步探索
- {{UNKNOWN_2}} - 需要更多数据

---

## 性能数据摘要（如果相关）

| 指标 | 最佳方案 | 数值 | 对比基线 |
|------|----------|------|----------|
| {{METRIC}} | {{APPROACH}} | {{VALUE}} | +X% / -Y% |

---

## 结论摘要

**一句话总结：**
{{ONE_SENTENCE_SUMMARY}}

**总体评估：**
- ✅ 假设已验证，建议继续
- ⚠️ 部分验证，需要更多探索
- ❌ 假设被推翻，建议放弃或转向

**置信度：** 高 / 中 / 低

**下一步建议：**
{{NEXT_STEPS_RECOMMENDATION}}