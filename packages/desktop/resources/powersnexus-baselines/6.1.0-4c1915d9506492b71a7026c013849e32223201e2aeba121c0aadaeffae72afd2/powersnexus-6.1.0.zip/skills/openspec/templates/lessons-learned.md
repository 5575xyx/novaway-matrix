# Lessons Learned - Project Knowledge Base

> 模板来源：PowersNexus OpenSpec
> 路径：`.novaway/powersnexus/knowledge/lessons-learned.md`
> 用途：项目经验教训总览，沉淀历史经验供后续项目参考

---

## 项目概览

| 项目 | 内容 |
|------|------|
| **项目名称** | {{PROJECT_NAME}} |
| **知识库版本** | v1.0 |
| **最后更新** | {{LAST_UPDATED}} |
| **累计经验条目** | {{COUNT}} 条 |

---

## 经验教训分类

### 🏗️ 架构设计

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

**详情：** 见 `patterns/` 和 `best-practices/` 相关文档

---

### 🔐 安全相关

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

**详情：** 见 `common-mistakes/security-gotchas.md`

---

### ⚡ 性能优化

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

**详情：** 见 `common-mistakes/performance-pitfalls.md`

---

### 🧪 测试策略

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

---

### 📦 数据库设计

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

---

### 🔄 并发与竞态

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

**详情：** 见 `common-mistakes/race-conditions.md`

---

### 🤖 AI 开发特有

| # | 教训 | 来源项目/任务 | 严重程度 | 日期 |
|---|------|---------------|----------|------|
| 1 | {{LESSON}} | {{SOURCE}} | 高/中/低 | {{DATE}} |

---

## 最佳实践索引

| 领域 | 文档 | 最后更新 |
|------|------|----------|
| 认证与授权 | `best-practices/authentication.md` | {{DATE}} |
| API 设计 | `best-practices/api-design.md` | {{DATE}} |
| 数据库 | `best-practices/database.md` | {{DATE}} |
| 测试 | `best-practices/testing.md` | {{DATE}} |

---

## 常见陷阱索引

| 类别 | 文档 | 最后更新 |
|------|------|----------|
| 竞态条件 | `common-mistakes/race-conditions.md` | {{DATE}} |
| 安全陷阱 | `common-mistakes/security-gotchas.md` | {{DATE}} |
| 性能陷阱 | `common-mistakes/performance-pitfalls.md` | {{DATE}} |

---

## 可复用模式索引

| 模式名称 | 文档 | 最后更新 |
|----------|------|----------|
| CRUD API | `patterns/crud-api.md` | {{DATE}} |
| 实时协作 | `patterns/realtime-collab.md` | {{DATE}} |
| 支付集成 | `patterns/payment-integration.md` | {{DATE}} |

---

## 最近添加的经验

| 日期 | 教训 | 分类 | 来源 |
|------|------|------|------|
| {{DATE}} | {{LESSON}} | {{CATEGORY}} | {{SOURCE}} |

---

## 使用指南

**何时读取知识库：**
- 🧠 开始新功能设计前 → 检查 best-practices 和 patterns
- 🔍 遇到问题时 → 检查 common-mistakes
- 📋 规划任务时 → 检查 lessons-learned 避免重蹈覆辙
- 🎨 做架构决策时 → 检查 patterns 寻找成熟方案

**何时写入知识库：**
- ✅ 项目完成后 → 复盘总结，添加经验教训
- 🐛 修复重大 Bug 后 → 记录根因和预防措施
- 🎯 完成探索任务后 → 沉淀发现和最佳实践
- 📚 发现通用模式后 → 整理为 patterns 文档

---

## 贡献记录

| 日期 | 贡献者 | 添加内容 | 备注 |
|------|--------|----------|------|
| {{DATE}} | {{AUTHOR}} | {{CONTENT}} | {{NOTE}} |