# Exploration Log

> 模板来源：PowersNexus OpenSpec
> 路径：`.novaway/powersnexus/explorations/<name>/exploration-log.md`
> 用途：记录探索过程中的日常日志、尝试的方案、遇到的问题等

---

## 基本信息

| 项目 | 内容 |
|------|------|
| **探索名称** | {{EXPLORATION_NAME}} |
| **开始日期** | {{START_DATE}} |
| **目标** | {{GOAL}} |
| **假设** | {{HYPOTHESIS}} |
| **时间盒** | {{TIMEBOX}} |

---

## 每日日志

### Day 1: {{DATE}}

**今日目标：**
- [ ] {{GOAL_1}}
- [ ] {{GOAL_2}}

**尝试的方案：**

#### Approach 1: {{NAME}}
- **思路：** {{DESCRIPTION}}
- **操作：** {{STEPS_TAKEN}}
- **结果：** ✅ 成功 / ❌ 失败 / ⚠️ 部分成功
- **发现：** {{FINDINGS}}
- **问题：** {{ISSUES}}

#### Approach 2: {{NAME}}
- **思路：** {{DESCRIPTION}}
- **操作：** {{STEPS_TAKEN}}
- **结果：** ✅ 成功 / ❌ 失败 / ⚠️ 部分成功
- **发现：** {{FINDINGS}}
- **问题：** {{ISSUES}}

**有用的资源：**
- [资源名称](URL) - {{DESCRIPTION}}
- [资源名称](URL) - {{DESCRIPTION}}

**今日总结：**
{{SUMMARY}}

**明日计划：**
- [ ] {{TODO_1}}
- [ ] {{TODO_2}}

---

### Day 2: {{DATE}}

[... 继续记录 ...]

---

## 完整尝试清单

| # | 方案 | 日期 | 结果 | 关键发现 |
|---|------|------|------|----------|
| 1 | {{APPROACH}} | {{DATE}} | ✅/❌/⚠️ | {{FINDING}} |
| 2 | {{APPROACH}} | {{DATE}} | ✅/❌/⚠️ | {{FINDING}} |

---

## 遇到的问题及解决方案

| 问题 | 严重程度 | 解决方案 | 状态 |
|------|----------|----------|------|
| {{PROBLEM}} | 高/中/低 | {{SOLUTION}} | ✅ 解决 / ⚠️ 部分解决 / ❌ 未解决 |

---

## 性能数据（如果相关）

| 指标 | 方案 A | 方案 B | 基线 |
|------|--------|--------|------|
| 响应时间 | {{VALUE}} | {{VALUE}} | {{VALUE}} |
| 吞吐量 | {{VALUE}} | {{VALUE}} | {{VALUE}} |
| 内存使用 | {{VALUE}} | {{VALUE}} | {{VALUE}} |

---

**使用说明：**
- 每次尝试都要记录，不管成功失败
- 详细记录操作步骤，便于复现
- 记录所有有用的资源链接
- 每天结束时做总结和明日计划