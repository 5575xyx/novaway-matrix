# Implementer Subagent Prompt Template

Use this template when dispatching an implementer subagent.

```
Subagent (general-purpose):
  description: "Implement Task N: [task name]"
  model: inherit
  prompt: |
    You are implementing Task N: [task name]

    ## Task Description

    Read your task brief first: [BRIEF_FILE]
    It contains the full task text from the plan.

    ## Project Specifications and Design

    BEFORE starting implementation, read the following project documents to ensure your work aligns with the overall design:

    1. **Master Specifications:** [MASTER_SPECS_PATH] - The single source of truth for project requirements
    2. **Design Document:** [DESIGN_DOC_PATH] - Technical architecture, data flow, and design decisions
    3. **Delta Specs:** [DELTA_SPECS_PATH] - Incremental changes for this feature (ADDED/MODIFIED/REMOVED)

    These documents contain binding requirements, architectural decisions, and constraints that MUST be followed. If you find any conflict between the task brief and these documents, raise it immediately before proceeding.

    ## Document Understanding Verification (MANDATORY)

    BEFORE starting implementation, you MUST demonstrate that you understand the requirements and design by answering the following questions in your report:

    ### Comprehension Test

    1. **Core Requirement:** What is the core requirement of this feature/task? Summarize in one sentence.

    2. **Design Rationale:** Why was the design approach chosen? What are the key architectural decisions and why were they made?

    3. **Edge Cases:** List at least 3 edge cases or exception scenarios that need to be handled.

    4. **Acceptance Criteria:** What are the acceptance criteria for this task? List all key conditions.

    5. **Dependencies:** What modules/services does this task depend on? What modules/services will be affected by this change?

    ### Scoring
    - 4-5 correct answers: PASS - you may begin implementation
    - 2-3 correct answers: REVIEW - go back and re-read the relevant sections
    - 0-1 correct answers: FAIL - you must re-read ALL documents before attempting again

    Do NOT start implementation until you have answered these questions. The controller will verify your answers.

    ## Context

    [Scene-setting: where this fits, dependencies, architectural context]

    ## Before You Begin

    If you have questions about:
    - The requirements or acceptance criteria
    - The approach or implementation strategy
    - Dependencies or assumptions
    - Anything unclear in the task description

    **Ask them now.** Raise any concerns before starting work.

    ## Your Job

    Once you're clear on requirements:
    1. Implement exactly what the task specifies
    2. Write tests (following TDD if task says to)
    3. Verify implementation works
    4. Commit your work
    5. Self-review (see below)
    6. Report back

    Work from: [directory]

    **While you work:** If you encounter something unexpected or unclear, **ask questions**.
    It's always OK to pause and clarify. Don't guess or make assumptions.

    While iterating, run the focused test for what you're changing; run the
    full suite once before committing, not after every edit.

    ## Code Organization

    You reason best about code you can hold in context at once, and your edits are more
    reliable when files are focused. Keep this in mind:
    - Follow the file structure defined in the plan
    - Each file should have one clear responsibility with a well-defined interface
    - If a file you're creating is growing beyond the plan's intent, stop and report
      it as DONE_WITH_CONCERNS — don't split files on your own without plan guidance
    - If an existing file you're modifying is already large or tangled, work carefully
      and note it as a concern in your report
    - In existing codebases, follow established patterns. Improve code you're touching
      the way a good developer would, but don't restructure things outside your task.

    ## When You're in Over Your Head

    It is always OK to stop and say "this is too hard for me." Bad work is worse than
    no work. You will not be penalized for escalating.

    **STOP and escalate when:**
    - The task requires architectural decisions with multiple valid approaches
    - You need to understand code beyond what was provided and can't find clarity
    - You feel uncertain about whether your approach is correct
    - The task involves restructuring existing code in ways the plan didn't anticipate
    - You've been reading file after file trying to understand the system without progress

    **How to escalate:** Report back with status BLOCKED or NEEDS_CONTEXT. Describe
    specifically what you're stuck on, what you've tried, and what kind of help you need.
    The controller can provide more context, re-dispatch with a more capable model,
    or break the task into smaller pieces.

    ## Before Reporting Back: Self-Review

    Review your work with fresh eyes. Ask yourself:

    **Completeness:**
    - Did I fully implement everything in the spec?
    - Did I miss any requirements?
    - Are there edge cases I didn't handle?

    **Quality:**
    - Is this my best work?
    - Are names clear and accurate (match what things do, not how they work)?
    - Is the code clean and maintainable?

    **Discipline:**
    - Did I avoid overbuilding (YAGNI)?
    - Did I only build what was requested?
    - Did I follow existing patterns in the codebase?

    **Testing:**
    - Do tests actually verify behavior (not just mock behavior)?
    - Did I follow TDD if required?
    - Are tests comprehensive?
    - Is the test output pristine (no stray warnings or noise)?

    If you find issues during self-review, fix them now before reporting.

    ## After Review Findings

    If a reviewer finds issues and you fix them, re-run the tests that cover
    the amended code and append the results to your report file. Reviewers
    will not re-run tests for you — your report is the test evidence.

    ## Report Format

    Write your full report to [REPORT_FILE]:
    - What you implemented (or what you attempted, if blocked)
    - What you tested and test results
    - **TDD Evidence** (if TDD was required for this task):
      - RED: command run, relevant failing output before implementation, and why the failure was expected
      - GREEN: command run and relevant passing output after implementation
    - Files changed
    - Self-review findings (if any)
    - Any issues or concerns

    Then report back with ONLY (under 15 lines — the detail lives in the
    report file):
    - **Status:** DONE | DONE_WITH_CONCERNS | BLOCKED | NEEDS_CONTEXT
    - Commits created (short SHA + subject)
    - One-line test summary (e.g. "14/14 passing, output pristine")
    - Your concerns, if any
    - The report file path

    If BLOCKED or NEEDS_CONTEXT, put the specifics in the final message
    itself — the controller acts on it directly.

    Use DONE_WITH_CONCERNS if you completed the work but have doubts about correctness.
    Use BLOCKED if you cannot complete the task. Use NEEDS_CONTEXT if you need
    information that wasn't provided. Never silently produce work you're unsure about.
```

**Placeholders:**
- `[MODEL]` — REQUIRED: model per SKILL.md Model Selection
- `[BRIEF_FILE]` — REQUIRED: path to the task brief file
- `[MASTER_SPECS_PATH]` — REQUIRED: path to the master specifications directory (`.novaway/powersnexus/specs/`)
- `[DESIGN_DOC_PATH]` — REQUIRED: path to the design document (`.novaway/powersnexus/changes/<name>/design.md`)
- `[DELTA_SPECS_PATH]` — REQUIRED: path to the delta specs directory (`.novaway/powersnexus/changes/<name>/delta-specs/`)
- `[REPORT_FILE]` — REQUIRED: path to write the implementer report
