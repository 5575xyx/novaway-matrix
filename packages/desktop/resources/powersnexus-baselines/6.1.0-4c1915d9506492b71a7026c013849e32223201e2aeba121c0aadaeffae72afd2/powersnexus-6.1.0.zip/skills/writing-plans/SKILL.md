---
name: writing-plans
description: Use when you have a spec or requirements for a multi-step task, before touching code
---

# Writing Plans

## Overview

Write comprehensive implementation plans assuming the engineer has zero context for our codebase and questionable taste. Document everything they need to know: which files to touch for each task, code, testing, docs they might need to check, how to test it. Give them the whole plan as bite-sized tasks. DRY. YAGNI. TDD. Frequent commits.

Assume they are a skilled developer, but know almost nothing about our toolset or problem domain. Assume they don't know good test design very well.

**Announce at start:** "I'm using the writing-plans skill to create the implementation plan."

**Context:** If working in an isolated worktree, it should have been created via the `PowersNexus:using-git-worktrees` skill at execution time.

**Save plans to:** `.novaway/powersnexus/changes/<name>/tasks.md`
- (User preferences for plan location override this default)
- Read existing tasks from `.novaway/powersnexus/changes/<name>/tasks.md` if it exists from brainstorming

## Scope Check

If the spec covers multiple independent subsystems, it should have been broken into sub-project specs during brainstorming. If it wasn't, suggest breaking this into separate plans — one per subsystem. Each plan should produce working, testable software on its own.

## File Structure

Before defining tasks, map out which files will be created or modified and what each one is responsible for. This is where decomposition decisions get locked in.

- Design units with clear boundaries and well-defined interfaces. Each file should have one clear responsibility.
- You reason best about code you can hold in context at once, and your edits are more reliable when files are focused. Prefer smaller, focused files over large ones that do too much.
- Files that change together should live together. Split by responsibility, not by technical layer.
- In existing codebases, follow established patterns. If the codebase uses large files, don't unilaterally restructure - but if a file you're modifying has grown unwieldy, including a split in the plan is reasonable.

This structure informs the task decomposition. Each task should produce self-contained changes that make sense independently.

## Task Right-Sizing

A task is the smallest unit that carries its own test cycle and is worth a
fresh reviewer's gate. When drawing task boundaries: fold setup,
configuration, scaffolding, and documentation steps into the task whose
deliverable needs them; split only where a reviewer could meaningfully
reject one task while approving its neighbor. Each task ends with an
independently testable deliverable.

## Bite-Sized Task Granularity

**Each step is one action (2-5 minutes):**
- "Write the failing test" - step
- "Run it to make sure it fails" - step
- "Implement the minimal code to make the test pass" - step
- "Run the tests and make sure they pass" - step
- "Commit" - step

## Plan Document Header

**Every plan MUST start with this header:**

```markdown
# [Feature Name] Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use PowersNexus:subagent-driven-development (recommended) or PowersNexus:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** [One sentence describing what this builds]

**Architecture:** [2-3 sentences about approach]

**Tech Stack:** [Key technologies/libraries]

## Global Constraints

[The spec's project-wide requirements — version floors, dependency limits,
naming and copy rules, platform requirements — one line each, with exact
values copied verbatim from the spec. Every task's requirements implicitly
include this section.]

## Acceptance Criteria

[End-to-end conditions that must be true for this feature to be considered
complete. These are testable, objective statements. Each should map to a
verification step in the final integration test task.]

## Non-Functional Requirements

[Quality attributes that the implementation must satisfy:

- **Performance:** response time targets, throughput requirements, memory limits
- **Reliability:** error rates, availability targets, retry policies
- **Security:** authentication requirements, data protection, input validation
- **Maintainability:** code quality standards, documentation requirements
- **Observability:** logging, metrics, error reporting requirements

For user-interface work, also include the approved visual contract: design system or token source, responsive breakpoints, component states, accessibility expectations, and desktop/mobile visual acceptance evidence.

Include only what's relevant. Copy exact values from the spec if present.]

---
```

## Task Structure

````markdown
### Task N: [Component Name]

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `exact/path/to/existing.py:123-145`
- Test: `tests/exact/path/to/test.py`

**Interfaces:**
- Consumes: [what this task uses from earlier tasks — exact signatures]
- Produces: [what later tasks rely on — exact function names, parameter
  and return types. A task's implementer sees only their own task; this
  block is how they learn the names and types neighboring tasks use.]

- [ ] **Step 1: Write the failing test**

```python
def test_specific_behavior():
    result = function(input)
    assert result == expected
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/path/test.py::test_name -v`
Expected: FAIL with "function not defined"

- [ ] **Step 3: Write minimal implementation**

```python
def function(input):
    return expected
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/path/test.py::test_name -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add tests/path/test.py src/path/file.py
git commit -m "feat: add specific feature"
```
````

## No Placeholders

Every step must contain the actual content an engineer needs. These are **plan failures** — never write them:
- "TBD", "TODO", "implement later", "fill in details"
- "Add appropriate error handling" / "add validation" / "handle edge cases"
- "Write tests for the above" (without actual test code)
- "Similar to Task N" (repeat the code — the engineer may be reading tasks out of order)
- Steps that describe what to do without showing how (code blocks required for code steps)
- References to types, functions, or methods not defined in any task

## Remember
- Exact file paths always
- Complete code in every step — if a step changes code, show the code
- Exact commands with expected output
- DRY, YAGNI, TDD, frequent commits

## Self-Review

After writing the complete plan, look at the spec with fresh eyes and check the plan against it. This is a checklist you run yourself — not a subagent dispatch.

**1. Spec coverage:** Skim each section/requirement in the spec. Can you point to a task that implements it? List any gaps.

**2. Acceptance criteria coverage:** Does the final integration/verification task cover every acceptance criterion? Each criterion must have a corresponding test or verification step.

**3. Non-functional requirements:** Are NFRs (performance, security, etc.) reflected in the plan? Do any tasks explicitly verify them? Add verification steps if missing.

**4. Placeholder scan:** Search your plan for red flags — any of the patterns from the "No Placeholders" section above. Fix them.

**5. Type consistency:** Do the types, method signatures, and property names you used in later tasks match what you defined in earlier tasks? A function called `clearLayers()` in Task 3 but `clearFullLayers()` in Task 7 is a bug.

**6. Integration test task:** Is there a final integration/end-to-end test task that verifies the whole feature works together? This should be the last task before completion.

**7. Delivery contract:** 对 L2+，计划必须包含填写 `delivery.json` 真实 argv、`powersnexus verify delivery <change-name>`、`powersnexus check delivery <change-name>` 与 `powersnexus archive <change-name>`。application 使用启动冒烟和健康检查，library 使用制品验证。

If you find issues, fix them inline. No need to re-review — just fix and move on. If you find a spec requirement with no task, add the task.

## Consistency Check (Auto-Verify)

**MANDATORY: Run the consistency check after self-review.**

Use the PowersNexus CLI tool to verify document consistency:

```bash
node src/cli/powersnexus-cli.js check consistency <change-name>
```

Or if `powersnexus` command is available:

```bash
powersnexus check consistency <change-name>
```

**What it checks:**
- Delta Spec 的每个 REQ-ID 都映射到 proposal.md、design.md、tasks.md 与 cross-reference.md
- 必需规划工件和至少一个 Delta Spec 均存在
- 任务完成度仅作进度展示；规划阶段允许未完成任务

**交付完成后：** 使用 `powersnexus check delivery <change-name>` 验证任务、追踪和 delivery.json 证据，再归档。

**If inconsistencies are found:**
- Fix them before proceeding
- Do NOT skip this step — inconsistent documents cause implementation failures
- Re-run the check after fixes until it passes

**If CLI tool is unavailable:**
- Manually verify cross-references as best you can
- Note the manual verification in deviations.md

## Execution Handoff

After saving the plan, 默认使用 `question` 工具提供执行选择；如果当前会话已经有自动本地交付授权，直接按推荐执行路径继续，不重复询问执行选择。

Question: "Plan complete and saved to `.novaway/powersnexus/changes/<name>/tasks.md`. Which execution approach would you like to use?"
Options:
- Subagent-Driven (recommended) - Fresh subagent per task with two-stage review
- Inline Execution - Execute tasks in this session with checkpoints

**If Subagent-Driven chosen:**
- **REQUIRED SUB-SKILL:** Use PowersNexus:subagent-driven-development
- Fresh subagent per task + two-stage review

**If Inline Execution chosen:**
- **REQUIRED SUB-SKILL:** Use PowersNexus:executing-plans
- Batch execution with checkpoints for review
